********************************************
Drupal 6 Social Networking
********************************************

Chapter 1 - No Code
Chapter 2 - No Code
Chapter 3 - No Code
Chapter 4 - NO CODE
Chapter 5 - NO CODE
Chapter 6 - No Code
Chapter 7 - Code Present
Chapter 8 - Code Present
Chapter 9 - NO CODE
Chapter 10 -NO CODE 
Chapter 11 -NO CODE 


This folder contains text files that contain the codes for the respective chapters.